<?php 
$hostname = "mariadb";
$username = "root";
$password = "password";
$database = "zvezdaopros";
$port = "3306";
$conn = mysqli_connect($hostname, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    function newblock($obj, $conn){
      $sql = "SELECT * FROM objects WHERE name LIKE '$obj%'";
      $result = $conn->query($sql);
      $html = "";
      $html .= "<div class='verevka'>
                  <img src='assets/verevka.png' alt='Object'>
                </div>";

      $html .= "<div class='container'>
                  <div class='object-card'>";
      if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
              $html .= "
                          <div class='image-wrapper' id=".$row['name'].">
                            <div class='card'>
                              <img src='".$row['img']."' alt='Object'>
                              <div class='description'>
                                  <h1>".$row['name']."</h1>
                                  <p>".$row['description']."</p>
                                  <input name='objvote' value=".$row['id']." type='checkbox' onclick='toggleCheck(this, ".$row['name'].")'>
                              </div>
                            </div>
                          </div>
                        ";
          }
      } else {
          $html .= "No results";
      }
      $html .= "  </div>
                </div>";
  
      return $html;
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="style_form.css">
  <title>Lending designed</title>
</head>
<body>
  <section>
    <input type="checkbox" id="check">
    <header>
      <h2><a href="#" class="logo">Logo</a></h2>
      <div class="navigator">
        <a href="#">Home</a>
        <a href="#">About</a>
        <a href="#">Info</a>
        <a href="#">Service</a>
        <a href="#">Contants</a>
      </div>
      <label for="check">
        <i class="fas fa-bars menu-btn"></i>
        <i class="fas fa-times close-btn"></i>
      </label>
    </header>
    <div class="content">
      <div class="info">
        <h2>Звездные Увалы<br><span>Голосование !</span></h2>
        <p>Описание</p>
        <a href="#" class="info-btn">More Info</a>
      </div>
    </div>
    

    <?php
    echo newblock('amfiteatr',$conn);
    echo newblock('art_object',$conn);
    echo newblock('besedka',$conn);
    echo newblock('camping',$conn);
    echo newblock('det_plosh',$conn);
    echo newblock('ecoshkila',$conn);
    echo newblock('glemping',$conn);
    echo newblock('liji_trassa',$conn);
    echo newblock('lijn_baza',$conn);
    echo newblock('mini_zoo',$conn);
    echo newblock('oranj',$conn);
    echo newblock('peshi',$conn);
    echo newblock('picnic',$conn);
    echo newblock('podemnik',$conn);
    echo newblock('prud',$conn);
    echo newblock('rodnik',$conn);
    echo newblock('smotr_plosh',$conn);
    echo newblock('trassa_downhill',$conn);
    echo newblock('trassa_tubing',$conn);
    echo newblock('WC',$conn);
    echo newblock('workout',$conn);
    echo newblock('zone_chill',$conn);
    ?>

            




              
  <style>
      .voterinfo{
        width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f2f2f2;
        border-radius: 5px;
        display: flex;
        flex-direction: column; 
        justify-content: center; /* Центрирование по горизонтали */
        align-items: center; /* Центрирование по вертикали */
      }
      label{ padding-top: 10px; font-size: 16px; text-align: center; }
      input{ height: 40px; font-size: 16px;  }
      select{ font-size: 16px;  }

  </style>
  <div class='voterinfo'>
      <div>
        <label for='firstname'>Имя:</label><input id='firstname'>
        <label for='lastname'>Фамилия:</label><input id='lastname'>
        <label for='patronymic'>Отчество:</label><input id='patronymic'>
      </div>
      <label for='birthday'>Год рождения</label><input type='date' id='birthday'>
      <label for='gender'>Пол:</label>
      <select id='gender'>
          <option value='male'>Мужской</option>
          <option value='female'>Женский</option>
      </select><br>
      <label for='text'>Ваше предложение:</label><textarea id='text' rows='20' cols='50' style='font-size: 16px'></textarea>
      <button style='margin-top: 10px; text-align: center' type='accept' id='acceptvote'>Проголосовать</button>
      <div id='res'></div>
  </div>
  
        <footer>
            <div class="media-icons">
               <!--
                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"><i class="fa-brands fa-github"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
               --> 
            </div>
        </footer>
        
    </section>
    <script src="index.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</body>
<?php
$conn->close();
?>
</html>