-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: mariadb
-- Время создания: Апр 04 2024 г., 11:35
-- Версия сервера: 10.11.7-MariaDB-1:10.11.7+maria~ubu2204
-- Версия PHP: 8.2.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `zvezdaopros`
--

-- --------------------------------------------------------

--
-- Структура таблицы `objects`
--

CREATE TABLE `objects` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `visname` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `objects`
--

INSERT INTO `objects` (`id`, `name`, `img`, `description`, `price`, `visname`) VALUES
(1, 'besedka_4', 'assets/besedka_4.jpg', NULL, NULL, NULL),
(2, 'besedka_6', 'assets/besedka_6.jpg', NULL, NULL, NULL),
(3, 'WC_1', 'assets/WC_1.jpg', NULL, NULL, NULL),
(4, 'art_object_1', 'assets/art_object_1.jpg', NULL, NULL, NULL),
(5, 'zone_chill_3', 'assets/zone_chill_3.jpg', NULL, NULL, NULL),
(6, 'lijn_baza_2', 'assets/lijn_baza_2.jpg', NULL, NULL, NULL),
(7, 'prud_1', 'assets/prud_1.jpg', NULL, NULL, NULL),
(8, 'zone_chill_1', 'assets/zone_chill_1.jpg', NULL, NULL, NULL),
(9, 'glemping_3', 'assets/glemping_3.jpg', NULL, NULL, NULL),
(10, 'turnilk', 'assets/turnilk.jpg', NULL, NULL, NULL),
(11, 'amfiteatr_1', 'assets/amfiteatr_1.jpg', NULL, NULL, NULL),
(12, 'camping_2', 'assets/camping_2.jpg', NULL, NULL, NULL),
(13, 'trassa_tubing_3', 'assets/trassa_tubing_3.jpg', NULL, NULL, NULL),
(14, 'stadion_2', 'assets/stadion_2.jpg', NULL, NULL, NULL),
(15, 'mini_zoo_3', 'assets/mini_zoo_3.jpg', NULL, NULL, NULL),
(16, 'rodnik_2', 'assets/rodnik_2.jpg', NULL, NULL, NULL),
(17, 'lijn_baza_1', 'assets/lijn_baza_1.jpg', NULL, NULL, NULL),
(18, 'glemping_2', 'assets/glemping_2.jpg', NULL, NULL, NULL),
(19, 'art_object_3', 'assets/art_object_3.jpg', NULL, NULL, NULL),
(20, 'ecoshkila_2', 'assets/ecoshkila_2.jpg', NULL, NULL, NULL),
(21, 'camping_1', 'assets/camping_1.jpg', NULL, NULL, NULL),
(22, 'ecoshkila_1', 'assets/ecoshkila_1.jpg', NULL, NULL, NULL),
(23, 'det_plosh_2', 'assets/det_plosh_2.jpg', NULL, NULL, NULL),
(24, 'trassa_downhill_1', 'assets/trassa_downhill_1.jpg', NULL, NULL, NULL),
(25, 'rodnik_1', 'assets/rodnik_1.jpg', NULL, NULL, NULL),
(26, 'trassa_tubing_1', 'assets/trassa_tubing_1.jpg', NULL, NULL, NULL),
(27, 'amfiteatr_2', 'assets/amfiteatr_2.jpg', NULL, NULL, NULL),
(28, 'det_plosh_1', 'assets/det_plosh_1.jpg', NULL, NULL, NULL),
(29, 'zone_chill_4', 'assets/zone_chill_4.jpg', NULL, NULL, NULL),
(30, 'zone_chill_2', 'assets/zone_chill_2.jpg', NULL, NULL, NULL),
(31, 'workout_1', 'assets/workout_1.jpg', NULL, NULL, NULL),
(32, 'art_object_4', 'assets/art_object_4.jpg', NULL, NULL, NULL),
(33, 'besedka_2', 'assets/besedka_2.jpg', NULL, NULL, NULL),
(34, 'prud_2', 'assets/prud_2.jpg', NULL, NULL, NULL),
(35, 'liji_trassa_1', 'assets/liji_trassa_1.jpg', NULL, NULL, NULL),
(36, 'glemping_1', 'assets/glemping_1.jpg', NULL, NULL, NULL),
(37, 'picnic_place_2', 'assets/picnic_place_2.jpg', NULL, NULL, NULL),
(38, 'Pris-transformed', 'assets/Pris-transformed.png', NULL, NULL, NULL),
(39, 'smotr_plosh_1', 'assets/smotr_plosh_1.jpg', NULL, NULL, NULL),
(40, 'fon', 'assets/fon.jpg', NULL, NULL, NULL),
(41, 'det_plosh_4', 'assets/det_plosh_4.jpg', NULL, NULL, NULL),
(42, 'picnic_place_3', 'assets/picnic_place_3.jpg', NULL, NULL, NULL),
(43, 'mini_zoo_2', 'assets/mini_zoo_2.jpg', NULL, NULL, NULL),
(44, 'oranj_2', 'assets/oranj_2.jpg', NULL, NULL, NULL),
(45, 'oranj_1', 'assets/oranj_1.jpg', NULL, NULL, NULL),
(46, 'det_plosh_3', 'assets/det_plosh_3.jpg', NULL, NULL, NULL),
(47, 'art_object_2', 'assets/art_object_2.jpg', NULL, NULL, NULL),
(48, 'trassa_downhill_2', 'assets/trassa_downhill_2.jpg', NULL, NULL, NULL),
(49, 'verevka', 'assets/verevka.png', NULL, NULL, NULL),
(50, 'Xwf0R1nVy_0', 'assets/Xwf0R1nVy_0.jpg', NULL, NULL, NULL),
(51, 'peshi_1', 'assets/peshi_1.jpg', NULL, NULL, NULL),
(52, 'mini_zoo_1', 'assets/mini_zoo_1.png', NULL, NULL, NULL),
(53, 'podemnik_1', 'assets/podemnik_1.jpg', NULL, NULL, NULL),
(54, 'besedka_5', 'assets/besedka_5.jpg', NULL, NULL, NULL),
(55, 'picnic_place_1', 'assets/picnic_place_1.jpg', NULL, NULL, NULL),
(56, 'besedka_1', 'assets/besedka_1.jpg', NULL, NULL, NULL),
(57, 'trassa_tubing_2', 'assets/trassa_tubing_2.jpg', NULL, NULL, NULL),
(58, 'stadion_1', 'assets/stadion_1.png', NULL, NULL, NULL),
(59, 'besedka_3', 'assets/besedka_3.jpg', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `voters`
--

CREATE TABLE `voters` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `predlozheniya` varchar(400) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `patronymic` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `voters`
--

INSERT INTO `voters` (`id`, `firstname`, `birthday`, `gender`, `predlozheniya`, `lastname`, `patronymic`) VALUES
(1, 'Максим', '2002-01-18', 'male', 'фыв', 'Пономарев', 'Сегреевич'),
(2, 'Максим', '2002-01-18', 'male', 'фыв', 'Пономарев', 'Сегреевич'),
(3, 'Максим', '2002-01-18', 'male', 'фыв', 'Пономарев', 'Сегреевич'),
(4, 'Максим', '2002-01-18', 'male', 'фыв', 'Пономарев', 'Сегреевич'),
(5, 'Паша', '2002-01-18', 'male', 'фыв', 'Пономарев', 'Сегреевич'),
(6, 'Паша', '2002-01-18', 'male', 'фыв', 'Пономарев', 'Сегреевич'),
(7, 'Паша', '2002-01-18', 'male', 'фыв', 'Пономарев', 'Сегреевич'),
(8, 'Паша', '2002-01-18', 'male', 'фыв', 'Пономарев', 'Сегреевич'),
(9, 'Паша', '2002-01-18', 'male', 'фыв', 'Пономарев', 'Сегреевич'),
(10, 'Паша', '2002-01-18', 'male', 'фыв', 'Стерхов', 'Сегреевич'),
(11, 'Катя', '2000-03-15', 'female', '', 'Путина', 'Владимировна');

-- --------------------------------------------------------

--
-- Структура таблицы `voter_selections`
--

CREATE TABLE `voter_selections` (
  `user_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `votingdate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `voter_selections`
--

INSERT INTO `voter_selections` (`user_id`, `object_id`, `votingdate`) VALUES
(4, 5, NULL),
(4, 11, NULL),
(4, 29, NULL),
(9, 8, '1970-01-01'),
(9, 11, '1970-01-01'),
(10, 8, '2024-04-04'),
(10, 11, '2024-04-04'),
(11, 8, '2024-04-04'),
(11, 11, '2024-04-04');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `objects`
--
ALTER TABLE `objects`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `voter_selections`
--
ALTER TABLE `voter_selections`
  ADD PRIMARY KEY (`user_id`,`object_id`),
  ADD KEY `object_id` (`object_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `objects`
--
ALTER TABLE `objects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `voters`
--
ALTER TABLE `voters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `voter_selections`
--
ALTER TABLE `voter_selections`
  ADD CONSTRAINT `voter_selections_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `voters` (`id`),
  ADD CONSTRAINT `voter_selections_ibfk_2` FOREIGN KEY (`object_id`) REFERENCES `objects` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
