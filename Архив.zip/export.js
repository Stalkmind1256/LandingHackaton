function exportDataToXML() {
    window.location.href = 'export_to_xml.php';
}