<?php
session_start();

$hostname = "mariadb";
$username = "root";
$password = "password";
$database = "zvezdaopros";
$port = "3306";
$connect = mysqli_connect($hostname,$username,$password,$database,$port);

if (!$connect){
    die('ERROR: '. mysql_error());
}

if ((!isset($_SESSION["admin"])) || ($_SESSION["admin"] != true)) {
    // Если администратор не вошел в систему, перенаправляем на страницу входа
    
    header("Location: registr.php");
    exit();
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
    <title>Admin panel</title>
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="generator" content="Geany 2.0" />
</head>

<body>
    <a>Меню администратора</a><br>
    <button onclick="loadData()">Загрузить данные</button>
    <button id='data_changer' onclick="changeData()" disabled>Изменить данные</button>
    <button id='save_new_data' disabled>Сохранить измененные данные</button>
<div id="dataContainer">
    <!-- Сюда будут вставлены данные -->
</div>

<script type="text/javascript">
function loadData() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            var response = JSON.parse(this.responseText);
            var table = '<table border="1"><thead><tr><th>ID</th><th>Имя</th><th>Фамилия</th><th>Отчество</th><th>Дата рождения</th><th>Пол</th><th>Предложения</th><th>Название объекта</th><th>Описание объекта</th><th>Цена</th><th>Видимое имя</th><th>Дата голосования</th></tr></thead><tbody>';
            for(var i = 0; i < response.length; i++) {
                var data = response[i];
                table += '<tr>' +
                         '<td id="1" contenteditable = false>' + data.user_id + '</td>' +
                         '<td id="2" contenteditable = false>' + data.firstname + '</td>' +
                         '<td id="3" contenteditable = false>' + data.lastname + '</td>' +
                         '<td id="4" contenteditable = false>' + data.patronymic + '</td>' +
                         '<td id="5" contenteditable = false>' + data.birthday + '</td>' +
                         '<td id="6" contenteditable = false>' + data.gender + '</td>' +
                         '<td id="7" contenteditable = false>' + data.predlozheniya + '</td>' +
                         '<td id="8" contenteditable = false>' + data.name + '</td>' +
                         '<td id="9" contenteditable = false>' + data.description + '</td>' +
                         '<td id="10" contenteditable = false>' + data.price + '</td>' +
                         '<td id="11" contenteditable = false>' + data.visname + '</td>' +
                         '<td id="12" contenteditable = false>' + data.votingdate + '</td>' +
                         '</tr>';
            }
            table += '</tbody></table>';
            document.getElementById("dataContainer").innerHTML = table;
        }
    };
    xmlhttp.open("GET", "fetch_data.php", true);
    xmlhttp.send();
    var button_enable = document.getElementById("data_changer");
    button_enable.disabled = false;
}
function changeData(){
    var button_enable_2 = document.getElementById("save_new_data");
    button_enable_2.disabled = false;

    var rows = document.querySelectorAll('#dataContainer tbody tr');
    
    // Для каждой строки...
    rows.forEach(function(row) {
        // Для каждой ячейки в строке, кроме первой (с ID пользователя)
        for (var i = 1; i < row.cells.length; i++) {
            // Устанавливаем атрибут contenteditable в 'true'
            row.cells[i].setAttribute('contenteditable', 'true');
        }
    });

    /*var c1 = document.getElementById("1");
    var c2 = document.getElementById("2");
    var c3 = document.getElementById("3");
    var c4 = document.getElementById("4");
    var c5 = document.getElementById("5");
    var c6 = document.getElementById("6");
    var c7 = document.getElementById("7");
    var c8 = document.getElementById("8");
    var c9 = document.getElementById("9");
    var c10 = document.getElementById("10");
    var c11 = document.getElementById("11");
    var c12 = document.getElementById("12");
    c1.contenteditable = true;
    c2.contenteditable = true;
    c3.contenteditable = true;
    c4.contenteditable = true;
    c5.contenteditable = true;
    c6.contenteditable = true;
    c7.contenteditable = true;
    c8.contenteditable = true;
    c9.contenteditable = true;
    c10.contenteditable = true;
    c11.contenteditable = true;
    c12.contenteditable = true;*/
}
</script>

</body>



</html>

<?php
mysqli_close($connect);
?>