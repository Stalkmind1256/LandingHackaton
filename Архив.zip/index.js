

let acceptbtn = document.getElementById('acceptvote');

acceptbtn.addEventListener('click', function(){
  acceptvote();
  
});

function acceptvote(){
  let checkboxes = document.querySelectorAll('input[name="objvote"]:checked');
  let selectedobjects = [];
  checkboxes.forEach(function(checkbox) {
    selectedobjects.push(checkbox.value);
  });
  let objects = JSON.stringify(selectedobjects);
  console.log(objects);
  let firstname = document.getElementById('firstname').value;
  let lastname = document.getElementById('lastname').value;
  let patronymic = document.getElementById('patronymic').value;
  let birthday = document.getElementById('birthday').value;
  let gender = document.getElementById('gender').value;
  let text = document.getElementById('text').value;
  let votedate = new Date();

  $.ajax({
    type: 'POST', 
    url: 'insertbd.php',
    data: {
      selectedobjects: objects,
      firstname: firstname,
      lastname: lastname,
      patronymic: patronymic,
      birthday: birthday,
      gender: gender,
      text: text,
      curdate: votedate,
    },
    success: function(result) { 
        
        $('#res').html(result);
    },
    error: function(xhr, status, error) {
        console.error('Ошибка при выполнении AJAX-запроса:', status, error);
    }
});

}